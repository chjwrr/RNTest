/**
 * Created by chj on 2018/4/10.
 */

import React, {Component} from 'react';
import {
    View,
    StyleSheet,
    Text
} from 'react-native';


export default class home extends Component {
    constructor(props) {
        super(props);


    }
    componentDidMount() {

    }

    render() {
        return <View style={styles.container}>
            <Text style={styles.title}>我的昵称</Text>
        </View>
    }
}

const styles =StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    title: {
        fontSize: 17
    }

});
