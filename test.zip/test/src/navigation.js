/**
 * Created by chj on 2018/4/10.
 */
import {TabNavigator} from "react-navigation";


import AppTab from './tabBar';



/*
 构造函数
 */
const Tab = TabNavigator(AppTab.AppRootTabBarRouteConfigs, AppTab.AppRootTabBarNavigatorConfigs);

/* 配置路由，所有要跳转的页面都需要在此声明 */

const AppNavigationRouterConfigs = {
    TabBar: {
        screen: Tab,
        navigationOptions: ({navigation}) => ({
            title: '测试',
        }),
    },

};


const AppNavigationStackConfigs = {
    initialRouteName: 'TabBar',
    initialRouteParams: {initParams: '初始化时传递参数'},
    mode: 'card',
    headerMode: 'screen',
    onTransitionStart: (() => {
        console.log('页面跳转动画开始');
    }),
    onTransitionEnd: (() => {
        console.log('页面跳转动画结束');
    }),
};

export default {
    AppNavigationRouterConfigs,
    AppNavigationStackConfigs
};
