const imageUrl = 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1523968418&di=354459f51990e7af8dee0641293250c3&imgtype=jpg&er=1&src=http%3A%2F%2Fwww.wallcoo.com%2Fanimal%2F2008_Animal_1680_Desktop_02%2Fwallpapers%2F1600x1200%2FTabby%2520Kitten%2520and%2520Spring%2520Flowers.jpg'
export {
    imageUrl
}