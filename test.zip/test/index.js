import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View
} from 'react-native';
import {StackNavigator} from "react-navigation";

import Navigator from './src/navigation';
import Feature from './src/containers/feature/feature'

/*
 navigation 构造函数
 */
const Navigation = StackNavigator(Navigator.AppNavigationRouterConfigs, Navigator.AppNavigationStackConfigs);


class index extends Component {

    render() {
        return (
            <Navigation
                onNavigationStateChange={(prevNav, nav, action)=>{}}
            />
        );
    }

}

AppRegistry.registerComponent('RNTest', () => index);
