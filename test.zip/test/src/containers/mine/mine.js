 /**
 * Created by chj on 2018/4/10.
 */

 import React, {Component} from 'react';
 import {
     View,
     Text,
     StyleSheet
 } from 'react-native';

 export default class mine extends Component {
     constructor(props) {
         super(props);
     }
     componentDidMount() {

     }

     render() {
         return <View style={styles.container}>
             <Text>push</Text>
         </View>
     }
 }

 const styles =StyleSheet.create({
     container: {
         flex: 1,
         backgroundColor: 'orange'
     },
 });
