/**
 * Created by chj on 2018/4/10.
 */

import React, {Component} from 'react';
import {
    StyleSheet,
    TouchableOpacity,
    Image
} from 'react-native';

import PropTypes from 'prop-types';


export default class showImage extends Component {

    render() {
        return  <TouchableOpacity style={[styles.container, {backgroundColor: 'red'}]} onPress={()=>{

            this.props.imageClick()
        }}>
            <Image source={{uri: this.props.imageURL}} style={styles.image}/>
        </TouchableOpacity>
    }
}

showImage.propTypes = {
    imageURL: PropTypes.string.isRequired,
    imageClick: PropTypes.func
};
showImage.defaultProps = {

};

const styles =StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F5FCFF',
    },
    image: {
        width: 160,
        height: 120
    }

});
