/**
 * Created by chj on 2018/4/10.
 */

import React, {Component} from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Modal,
    Image
} from 'react-native';

import Feature from '../feature/feature'
import ShowImage from '../../components/home/showImage'

import {imageUrl} from '../../constants/constValue'

export default class home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowModal: false,
            isShowFeature: true
        }

    }
    componentDidMount() {
        this.time=setTimeout(()=>{
            this.setState({
                isShowFeature: false
            })
        },3000)
    }

    componentWillMount() {
        this.time && clearTimeout(this.time)
    }

    render() {
        return <View style={styles.container}>
            <TouchableOpacity onPress={()=>{
                this.setState({
                    isShowModal: true
                })
            }}>
                <Text>按钮</Text>
            </TouchableOpacity>

            <Modal visible={this.state.isShowModal}
                   transparent={true}>
               <ShowImage imageURL={imageUrl}
                          imageClick={()=>{
                              this.setState({
                                  isShowModal: false
                              })
                          }}/>
            </Modal>


            <Modal visible={this.state.isShowFeature }>
                <Feature />
            </Modal>


        </View>
    }
}

const styles =StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F5FCFF',
    },
    image: {
        width: 160,
        height: 120
    }

});
