/**
 * Created by chj on 2018/4/10.
 */

import React, { Component } from 'react';
import {
    Text,
} from 'react-native';

import {TabBarBottom} from "react-navigation";

import Home from './containers/home/home';
import Mine from './containers/mine/mine';


const AppRootTabBarRouteConfigs = {
    Home:{
        screen: Home,
        navigationOptions: {
            tabBarLabel: '首页',
        }
    },
    Mine:{
        screen: Mine,
        navigationOptions: {
            tabBarLabel: '我的',
        }
    },
};

const AppRootTabBarNavigatorConfigs = {
    initialRouteName: 'Home',
    tabBarComponent: TabBarBottom,
    tabBarPosition: 'bottom',
    lazy: true,
    tabBarOptions: {
        activeTintColor: 'red',
        inactiveTintColor: 'black',
        showLabel: true,
        style:{ // 在此处可以设置tabbar的属性，height、marginBottom等。iPhone X适配时，需要在此处进行适配处理
            backgroundColor: 'yellow',
        },
        labelStyle: {  // 在此处可以设置tabbar的title的属性，大小、颜色等
            fontWeight: 'bold',
            fontSize: 12,
        },
        iconStyle: {
            // 在此处可以设置tabbar的icon的属性
        }
    }
};

export default {
    AppRootTabBarRouteConfigs,
    AppRootTabBarNavigatorConfigs
};